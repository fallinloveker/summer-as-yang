package com.say.tikujun.pojo;

import lombok.Data;

@Data
public class StudentQuestionInfo {
    Integer id_s;
}
