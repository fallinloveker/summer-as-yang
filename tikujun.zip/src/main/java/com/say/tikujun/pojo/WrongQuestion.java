package com.say.tikujun.pojo;

import lombok.Data;

@Data
public class WrongQuestion {
    private Integer id_s;
    private String type;
}
