package com.say.tikujun.pojo;

import lombok.Data;

@Data
public class CollectionBar {
    Integer id_s;
    Integer id_q;
    String operation;
}
