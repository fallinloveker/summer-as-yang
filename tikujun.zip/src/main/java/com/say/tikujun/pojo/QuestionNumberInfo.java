package com.say.tikujun.pojo;
import lombok.Data;

@Data
public class QuestionNumberInfo {
    Integer id_q;
    Integer number_a;
    Integer number_b;
    Integer number_c;
    Integer number_d;
    Integer number_true;
    Integer number_all;
}
