package com.say.tikujun.pojo;

import lombok.Data;

@Data
public class Login {
    private Integer contact;
    private String password;
}
