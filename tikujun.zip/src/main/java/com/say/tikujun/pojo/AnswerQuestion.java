package com.say.tikujun.pojo;

import lombok.Data;

@Data
public class AnswerQuestion {
    private Integer id;
    private String subject;
    private String subtype;
}
