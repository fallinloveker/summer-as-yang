package com.say.tikujun.pojo;

import lombok.Data;

@Data
public class Register {
    String name;
    Integer contact;
    String password1;
    String password2;
}
