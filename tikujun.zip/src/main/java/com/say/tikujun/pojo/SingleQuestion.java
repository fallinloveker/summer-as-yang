package com.say.tikujun.pojo;

import lombok.Data;

@Data
public class SingleQuestion {
    private Integer id_s;
    private Integer id_q;
}
