package com.say.tikujun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TikujunApplication {

    public static void main(String[] args) {
        SpringApplication.run(TikujunApplication.class, args);
    }

}
