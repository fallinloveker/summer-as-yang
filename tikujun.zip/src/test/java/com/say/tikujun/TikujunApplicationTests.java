package com.say.tikujun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TikujunApplicationTests {

    @Test
    void contextLoads() {
    }

}
